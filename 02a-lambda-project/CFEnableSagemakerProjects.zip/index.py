# Function: CFEnableSagemakerProjects
# Purpose:  Enables Sagemaker Projects
import json
import boto3
import cfnresponse
import time

client = boto3.client('sagemaker')
sc_client = boto3.client('servicecatalog')

def lambda_handler(event, context):
    #response_status = cfnresponse.SUCCESS
    execution_role = event['detail']['requestParameters']['defaultUserSettings']['executionRole']
    print(str(execution_role))
    if event['detail']['eventName'] == 'CreateDomain':
        #time_to_wait = int(event['ResourceProperties']['TimeToWait'])
        time_to_wait = int('300') # in seconds
        print(f'Waiting for {time_to_wait} seconds')
        time.sleep(time_to_wait)
        print(f'Waiting finished')
        enable_projects(execution_role)
    #cfnresponse.send(event, context, response_status, {}, '')
    

def enable_projects(studio_role_arn):
    # enable Project on account level (accepts portfolio share)
    response = client.enable_sagemaker_servicecatalog_portfolio()

    # associate studio role with portfolio - where the sample projects are
    response = sc_client.list_accepted_portfolio_shares()

    portfolio_id = ''
    for portfolio in response['PortfolioDetails']:
        if portfolio['ProviderName'] == 'Amazon SageMaker':
            portfolio_id = portfolio['Id']
    print(str(portfolio_id))
    print(str(studio_role_arn))
    response = sc_client.associate_principal_with_portfolio(
        PortfolioId=portfolio_id,
        PrincipalARN=studio_role_arn,
        PrincipalType='IAM'
    )
    print(str(response))